package recyclerview.expandable.hb.expandablerecyclerview

/**
 * ExpandableRecyclerView
 *
 * Created By hasmukh.bhadani on 12-Sep-18
 *
 * Copyright Softweb Solutions Inc. 2018,  All rights reserved.
 */
class ChildItemBean
{

    var mTitle: String = "ChildItem"

}