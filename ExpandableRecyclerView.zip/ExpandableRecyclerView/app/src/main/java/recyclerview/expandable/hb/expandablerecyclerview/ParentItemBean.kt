package recyclerview.expandable.hb.expandablerecyclerview

import com.bignerdranch.expandablerecyclerview.Model.ParentListItem



/**
 * ExpandableRecyclerView
 *
 * Created By hasmukh.bhadani on 12-Sep-18
 *
 * Copyright Softweb Solutions Inc. 2018,  All rights reserved.
 */
internal class ParentItemBean : ParentListItem
{
    var mTitle: String = "ParentItem"
    private var mChildItemList: List<ChildItemBean>? = null

    override fun getChildItemList(): List<ChildItemBean>?
    {
        return mChildItemList
    }

    fun setChildItemList(list: List<ChildItemBean>)
    {
        mChildItemList = list
    }

    override fun isInitiallyExpanded(): Boolean
    {
        return false
    }
}