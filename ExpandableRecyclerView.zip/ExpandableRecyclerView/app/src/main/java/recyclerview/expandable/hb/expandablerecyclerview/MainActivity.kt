package recyclerview.expandable.hb.expandablerecyclerview

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.View
import com.bignerdranch.expandablerecyclerview.Adapter.ExpandableRecyclerAdapter


class MainActivity : AppCompatActivity()
{

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recyclerView = findViewById<View>(R.id.recycler_view) as RecyclerView
        val layoutManager = LinearLayoutManager(this)
        recyclerView.layoutManager = layoutManager;


        val headerListItemsArrayList = ArrayList<ParentItemBean>()
        for (i in 0..4)
        {
            val eachParentItem = ParentItemBean()
            eachParentItem.mTitle = "Header $i"
            headerListItemsArrayList.add(eachParentItem)
        }

        val parentListArrayList = ArrayList<ParentItemBean>()
        for (headerBean in headerListItemsArrayList)
        {
            val childItemList = ArrayList<ChildItemBean>()
            for (i in 0..2)
            {
                val  childItemBean = ChildItemBean()
                childItemBean.mTitle= "Item $i"
                childItemList.add(childItemBean)
            }
            headerBean.setChildItemList(childItemList)
            parentListArrayList.add(headerBean)
        }

        val adapter = CategoryExpandableRecyclerAdapter(this, parentListArrayList)
        recyclerView.adapter = adapter

        var lastExpandedPosition = -1
        adapter.setExpandCollapseListener(object : ExpandableRecyclerAdapter.ExpandCollapseListener{
            override fun onListItemCollapsed(position: Int)
            {
            }

            override fun onListItemExpanded(position: Int)
            {
                if (lastExpandedPosition != -1 && position != lastExpandedPosition)
                {
                    adapter.collapseParent(lastExpandedPosition)
                }
                lastExpandedPosition = position
            }
        })



    }
}
