package recyclerview.expandable.hb.expandablerecyclerview

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.bignerdranch.expandablerecyclerview.Adapter.ExpandableRecyclerAdapter
import com.bignerdranch.expandablerecyclerview.Model.ParentListItem
import com.bignerdranch.expandablerecyclerview.ViewHolder.ChildViewHolder
import com.bignerdranch.expandablerecyclerview.ViewHolder.ParentViewHolder


/**
 * ExpandableRecyclerView
 *
 * Created By hasmukh.bhadani on 12-Sep-18
 *
 * Copyright Softweb Solutions Inc. 2018,  All rights reserved.
 */
internal class CategoryExpandableRecyclerAdapter(context: Context, itemList: List<ParentListItem>) :
        ExpandableRecyclerAdapter<CategoryExpandableRecyclerAdapter.MyParentViewHolder, CategoryExpandableRecyclerAdapter.MyChildViewHolder>(itemList)
{
    private val mInflater: LayoutInflater = LayoutInflater.from(context)

    //Parent View Holder
    override fun onCreateParentViewHolder(viewGroup: ViewGroup): MyParentViewHolder
    {
        val view = mInflater.inflate(R.layout.item_subcategory_fragment_elv_group, viewGroup, false)
        return MyParentViewHolder(view)
    }

    //Child View Holder
    override fun onCreateChildViewHolder(viewGroup: ViewGroup): MyChildViewHolder
    {
        val view = mInflater.inflate(R.layout.item_subcategory_fragment_elv_child, viewGroup, false)
        return MyChildViewHolder(view)
    }

    //Bind Parent View Holder
    override fun onBindParentViewHolder(parentViewHolder: MyParentViewHolder, groupPosition: Int, parentListItem: ParentListItem)
    {
        val subcategoryParentListItem = parentListItem as ParentItemBean
        parentViewHolder.lblListHeader.text = subcategoryParentListItem.mTitle

    }

    //Child Parent View Holder
    override fun onBindChildViewHolder(childViewHolder: MyChildViewHolder, position: Int, childListItem: Any)
    {
        val subcategoryChildListItem = childListItem as ChildItemBean
        childViewHolder.txtListChild.text = subcategoryChildListItem.mTitle

    }

    inner class MyParentViewHolder(itemView: View) : ParentViewHolder(itemView)
    {
        var lblListHeader: TextView = itemView.findViewById(R.id.lblListHeader)
    }

    inner class MyChildViewHolder(itemView: View) : ChildViewHolder(itemView)
    {

        var txtListChild: TextView = itemView.findViewById(R.id.txtListChild)

    }
}