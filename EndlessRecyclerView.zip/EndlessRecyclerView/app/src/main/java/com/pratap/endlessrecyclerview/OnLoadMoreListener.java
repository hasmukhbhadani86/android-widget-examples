package com.pratap.endlessrecyclerview;

public interface OnLoadMoreListener {
	 void onLoadMore();
}
