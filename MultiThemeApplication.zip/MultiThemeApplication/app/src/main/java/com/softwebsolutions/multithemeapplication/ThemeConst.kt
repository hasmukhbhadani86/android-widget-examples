package com.softwebsolutions.multithemeapplication


/**
 * MultiThemeApplication
 *
 * Created By shirinafroz.ansari on 6/8/2018
 *
 * Copyright Softweb Solutions Inc. 2018,  All rights reserved.
 */
enum class ThemeConst(val themeType: String, val theme: Int)
{
    BLUE("Blue", R.style.AppTheme1),
    GREY("Grey", R.style.AppTheme2),
    GREEN("Green", R.style.AppTheme3),
    RED("Red", R.style.AppTheme4)
}

