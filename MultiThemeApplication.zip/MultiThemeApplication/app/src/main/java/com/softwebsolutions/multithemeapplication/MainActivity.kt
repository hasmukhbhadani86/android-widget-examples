package com.softwebsolutions.multithemeapplication

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity()
{
    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val spinnerArray = ArrayList<String>()
        spinnerArray.add("Select Theme")
        spinnerArray.addAll(arrayListOf(ThemeConst.BLUE.themeType, ThemeConst.GREY.themeType, ThemeConst.GREEN.themeType, ThemeConst.RED.themeType))

        val spinnerArrayAdapter = ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, spinnerArray)
        spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spTheme.adapter = spinnerArrayAdapter

        spTheme.onItemSelectedListener = object : AdapterView.OnItemSelectedListener
        {
            override fun onNothingSelected(parent: AdapterView<*>?)
            {

            }

            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long)
            {
                if (position != 0)
                {
                    val i = Intent(this@MainActivity, SecondActivity::class.java)
                    i.putExtra(getString(R.string.theme), spinnerArray[position])
                    startActivity(i)
                }
            }
        }
    }
}
