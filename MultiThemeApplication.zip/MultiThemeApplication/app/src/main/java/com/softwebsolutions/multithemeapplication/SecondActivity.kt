package com.softwebsolutions.multithemeapplication

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_second.*




class SecondActivity : AppCompatActivity()
{

    override fun onCreate(savedInstanceState: Bundle?)
    {

        var theme = ThemeConst.BLUE.theme
        if (intent.extras != null)
        {
            val themeName = intent.extras.getString(getString(R.string.theme))
            if (themeName != null)
            {
                val themeType = ThemeConst.values().find { info -> info.themeType.equals(themeName, true) }
                if (themeType != null) theme = themeType.theme
            }
        }
        setTheme(theme)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)


        val childCount = clMain.childCount
        for (i in 0 until childCount)
        {
            val element:View = clMain.getChildAt(i)
            if(element is Button)
            {
                element.setTextColor(Color.parseColor("#" + "C538A1"))

                val color = Color.parseColor("#AECA30")
                val bgShape = element.getBackground() as GradientDrawable
                bgShape.setColor(color)
            }
            else if(element is ImageView)
            {
                if(element.tag == "vectorImg")
                {
                    val color = Color.parseColor("#30380B")
                    (element.background as GradientDrawable).setColor(color)
                }
            }
            else if (element is TextView)
            {
                element.setTextColor(Color.parseColor("#" + "A38F3D"))
            }
        }
    }
}
